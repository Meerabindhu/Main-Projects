import Login from './Components/LoginPage';
import "./App.css";

function App() {
  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;
